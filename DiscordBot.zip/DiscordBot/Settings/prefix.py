# Bot command prefix
PREFIX = ","