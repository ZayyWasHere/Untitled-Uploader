# Server/guild information
GUILD = {
    "id": 1420280936263847958,
    "name": "I RIOT ﾒ",
    "owner_id": 1035577501184962592,
    "region": "us-west",
    "member_count": 100
}