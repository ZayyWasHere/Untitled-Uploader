# List of important role IDs in your server
ROLES = {
    "owner": 1420778090518286460,
    "staff": 1421295833416204329,
    "trial staff": 1438032147221844038,
    "muted": 1421304269495341327,
    "members": 1421295715560198266,
    "vip": 1438390648414666824
}
