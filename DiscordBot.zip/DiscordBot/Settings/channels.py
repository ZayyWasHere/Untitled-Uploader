# List of important channel IDs in your server
CHANNELS = {
    "welcome": 1420777091623813161,
    "verify": 1438049998402093128,
    "general": 1421298879495798907,
    "promo": 1441489985386578011

}