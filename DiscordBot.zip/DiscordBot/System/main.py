import discord
from discord.ext import commands
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")

# Import settings
from Settings.prefix import PREFIX

# Initialize bot (disable default help command to avoid conflicts)
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

# Load commands dynamically
async def load_commands():
    commands_path = os.path.abspath(os.path.join("Commands"))
    for filename in os.listdir(commands_path):
        if filename.endswith(".py") and filename != "__init__.py":
            extension = f"Commands.{filename[:-3]}"
            try:
                await bot.load_extension(extension)
                print(f"Loaded {extension}")
            except Exception as e:
                print(f"Failed to load {extension}: {e}")

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user.name}")
    await load_commands()

# Run bot
if __name__ == "__main__":
    bot.run(TOKEN)