import discord
from discord.ext import commands
from discord.ui import Button, View
from Settings.roles import ROLES
from Settings.channels import CHANNELS

class Verify(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        # Give the unverified role
        unverified_role = member.guild.get_role(1435778391977496616)
        await member.add_roles(unverified_role)

        # Send welcome embed in verify channel
        verify_channel = self.bot.get_channel(CHANNELS["verify"])
        embed = discord.Embed(
            title="Welcome to the server!",
            description=f"Welcome {member.mention}, in order to gain access to the rest of the server, you must verify your account. Click the button below to get started.",
            color=discord.Color.from_rgb(245, 245, 245)  # Ice white
        )
        embed.set_thumbnail(url=member.avatar.url if member.avatar else None)

        # Create the verify button
        button = Button(label="Click to verify", style=discord.ButtonStyle.success)  # Green button

        async def button_callback(interaction):
            if interaction.user != member:
                return await interaction.response.send_message("This button isn't for you!", ephemeral=True)

            # Remove unverified role and add member role
            member_role = member.guild.get_role(ROLES["members"])
            await member.remove_roles(unverified_role)
            await member.add_roles(member_role)

            # Send info embed to staff channel
            staff_channel = self.bot.get_channel(1438052220699541565)
            info_embed = discord.Embed(
                title="New Member Verified",
                description=f"{member} has completed verification.",
                color=discord.Color.from_rgb(18, 18, 18)  # Jet black
            )
            info_embed.add_field(name="Username", value=str(member), inline=True)
            info_embed.add_field(name="User ID", value=member.id, inline=True)
            info_embed.add_field(name="Joined Server", value=member.joined_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
            info_embed.set_thumbnail(url=member.avatar.url if member.avatar else None)
            await staff_channel.send(embed=info_embed)

            # Confirm to the user
            await interaction.response.edit_message(content="✅ Verification complete!", embed=None, view=None)

        button.callback = button_callback
        view = View()
        view.add_item(button)
        await verify_channel.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(Verify(bot))
