import discord
from discord.ext import commands

class Kick(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member = None, *, reason: str = "No reason provided"):
        if member is None:
            return await ctx.send("Please mention a user to kick.")

        if member == ctx.author:
            return await ctx.send("You cannot kick yourself.")

        try:
            await member.kick(reason=reason)
            await ctx.send(f"{member} has been kicked. Reason: {reason}")
        except discord.Forbidden:
            await ctx.send("I do not have permission to kick that user.")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(Kick(bot))
