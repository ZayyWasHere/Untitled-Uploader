import discord
from discord.ext import commands

class Warn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings = {}  # Temporary storage; can be replaced with a database later

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def warn(self, ctx, member: discord.Member = None, *, reason: str = "No reason provided"):
        if member is None:
            return await ctx.send("Please mention a user to warn.")

        if member == ctx.author:
            return await ctx.send("You cannot warn yourself.")

        guild_id = ctx.guild.id

        # Initialize guild section
        if guild_id not in self.warnings:
            self.warnings[guild_id] = {}

        # Initialize user warning list
        if member.id not in self.warnings[guild_id]:
            self.warnings[guild_id][member.id] = []

        # Add the warning
        self.warnings[guild_id][member.id].append(reason)

        await ctx.send(f"{member.mention} has been warned. Reason: {reason}")

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def warnings(self, ctx, member: discord.Member = None):
        if member is None:
            return await ctx.send("Please mention a user.")

        guild_id = ctx.guild.id

        if guild_id in self.warnings and member.id in self.warnings[guild_id]:
            warns = self.warnings[guild_id][member.id]

            if len(warns) == 0:
                return await ctx.send(f"{member.mention} has no warnings.")

            warning_list = "\n".join([f"`{i+1}.` {w}" for i, w in enumerate(warns)])
            await ctx.send(f"Warnings for {member.mention}:\n{warning_list}")
        else:
            await ctx.send(f"{member.mention} has no warnings.")

async def setup(bot):
    await bot.add_cog(Warn(bot))