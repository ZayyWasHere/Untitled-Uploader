import discord
from discord.ext import commands

class Role(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=["addrole", "removerole"])
    @commands.has_permissions(manage_roles=True)
    async def role(self, ctx, member: discord.Member = None, *, role_name: str = None):
        if member is None or role_name is None:
            return await ctx.send("Usage: ,role <member> <role name>")

        guild = ctx.guild
        role = discord.utils.get(guild.roles, name=role_name)

        if role is None:
            return await ctx.send("Role not found.")

        # Add or remove role
        if role in member.roles:
            try:
                await member.remove_roles(role)
                await ctx.send(f"Removed `{role.name}` from {member.mention}.")
            except discord.Forbidden:
                await ctx.send("I do not have permission to modify that role.")
        else:
            try:
                await member.add_roles(role)
                await ctx.send(f"Added `{role.name}` to {member.mention}.")
            except discord.Forbidden:
                await ctx.send("I do not have permission to modify that role.")

async def setup(bot):
    await bot.add_cog(Role(bot))