import discord
from discord.ext import commands
from Settings.prefix import PREFIX

class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def help(self, ctx):
        embed = discord.Embed(
            title="Bot Commands",
            description="Here is a list of available commands:",
            color=discord.Color.blue()
        )

        embed.add_field(name=f"{PREFIX}ban", value="Ban a user", inline=False)
        embed.add_field(name=f"{PREFIX}kick", value="Kick a user", inline=False)
        embed.add_field(name=f"{PREFIX}role", value="Add/remove a role to a user", inline=False)
        embed.add_field(name=f"{PREFIX}warn", value="Warn a user", inline=False)
        embed.add_field(name=f"{PREFIX}promo", value="Post your guns.lol profile (1 hour cooldown)", inline=False)

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Help(bot))
