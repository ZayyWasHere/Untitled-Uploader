import discord
from discord.ext import commands
import requests
from bs4 import BeautifulSoup
import re
from Settings.channels import CHANNELS
from Settings.roles import ROLES
import time

COOLDOWN = {}  # user_id: timestamp

class Promo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def promo(self, ctx, profile_link: str = None):
        member_role = discord.utils.get(ctx.guild.roles, id=ROLES["members"])
        if member_role not in ctx.author.roles:
            return await ctx.send("You need the Members role to use this command.")

        if ctx.channel.id != CHANNELS["general"]:
            return await ctx.send("You can only use this command in the general channel.")

        now = time.time()
        if ctx.author.id in COOLDOWN and now < COOLDOWN[ctx.author.id]:
            remaining = int(COOLDOWN[ctx.author.id] - now)
            return await ctx.send(f"You must wait {remaining // 60} minutes before using this command again.")

        if not profile_link or not re.match(r"https://guns\.lol/[\w-]+", profile_link):
            return await ctx.send("Please provide a valid Guns.lol profile link.")

        try:
            r = requests.get(profile_link)
            if r.status_code != 200:
                return await ctx.send("Could not fetch the profile. Make sure the link is correct and public.")

            soup = BeautifulSoup(r.text, "html.parser")

            # Get username
            username_tag = soup.find("h1")
            username = username_tag.text.strip() if username_tag else "Unknown"

            # Get profile picture
            pfp_tag = soup.find("img")
            pfp_url = pfp_tag["src"] if pfp_tag else None

            # Scrape all public stats
            stats_text = ""
            # Most Guns.lol pages have stats in divs or spans
            stat_containers = soup.find_all(["div", "span"], class_=re.compile("stat|info|value"))
            for s in stat_containers:
                text = s.get_text(strip=True)
                if text:
                    stats_text += f"{text}\n"

            if not stats_text:
                stats_text = "No public stats found."

            # Build embed
            embed = discord.Embed(
                title=f"{username}'s Guns.lol Profile",
                description=stats_text,
                color=discord.Color.green(),
                url=profile_link
            )
            if pfp_url:
                embed.set_thumbnail(url=pfp_url)
            embed.set_footer(text=f"Profile shared by {ctx.author.display_name}")

            promo_channel = self.bot.get_channel(CHANNELS["promo"])
            await promo_channel.send(embed=embed)

            # Set cooldown
            COOLDOWN[ctx.author.id] = now + 3600
            await ctx.send("Your profile has been posted successfully! You can use this command again in 1 hour.")

        except Exception as e:
            await ctx.send(f"Failed to fetch profile: {e}")

async def setup(bot):
    await bot.add_cog(Promo(bot))
