import discord
from discord.ext import commands

class Ban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member = None, *, reason: str = "No reason provided"):
        if member is None:
            return await ctx.send("Please mention a user to ban.")

        if member == ctx.author:
            return await ctx.send("You cannot ban yourself.")

        try:
            await member.ban(reason=reason)
            await ctx.send(f"{member} has been banned. Reason: {reason}")
        except discord.Forbidden:
            await ctx.send("I do not have permission to ban that user.")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(Ban(bot))